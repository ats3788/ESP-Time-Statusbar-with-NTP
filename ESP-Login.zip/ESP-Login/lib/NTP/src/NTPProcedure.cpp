#include "NTPProcedure.h"

const char* NTP_SERVER = "ch.pool.ntp.org";
const char* TZ_INFO    = "CET-1CEST-2,M3.5.0/02:00:00,M10.5.0/03:00:00";  // enter your time zone (https://remotemonitoringsystems.ca/time-zone-abbreviations.php)


/*
char *__findenv(const char *name, int *offset);
extern char **environ;


int setenv(const char *name, const char *value, int rewrite)
{
	static char **lastenv;			// last value of environ 
	char *C;
	int l_value, offset;
	if (*value == '=')			// no `=' in value 
		++value;
	l_value = strlen(value);
	if ((C = __findenv(name, &offset))) {	// find if already exists 
		if (!rewrite)
			return (0);
		if ((int)strlen(C) >= l_value) {	// old larger; copy over 
			while ((*C++ = *value++))
				;
			return (0);
		}
	} else {					// create new slot 
		size_t cnt;
		char **P;
		for (P = environ; *P != NULL; P++)
			;
		cnt = P - environ;
        P = (char **)realloc(lastenv, sizeof(char *) * (cnt + 2));
		if (!P)
			return (-1);
		if (lastenv != environ)
			memcpy(P, environ, cnt * sizeof(char *));
		lastenv = environ = P;
		offset = cnt;
		environ[cnt + 1] = NULL;
	}
	for (C = (char *)name; *C && *C != '='; ++C)
		;				// no `=' in name 
	if (!(environ[offset] =	C;		// name + `=' + value 
	   // malloc((size_t)((int)(C - name) + l_value + 2))))
		return (-1);
	for (C = environ[offset]; (*C = *name++) && *C != '='; ++C)
		;
	for (*C++ = '='; (*C++ = *value++); )
		;
	return (0);
}

*/
void SetNTP_SERVER()
{
  configTime(0, 0, NTP_SERVER);
  // See https://github.com/nayarsystems/posix_tz_db/blob/master/zones.csv for Timezone codes for your region
  setenv("TZ", TZ_INFO, 1); // This is Assember Code

}


bool getNTPtime(int sec, time_t & GetTime) 
{
  tm TimeStruct;
  {
    uint32_t start = millis();
    do {
      time(&GetTime);
      localtime_r(&GetTime, &TimeStruct);
      
      delay(10);
    } while (((millis() - start) <= (1000 * sec)) && (TimeStruct.tm_year < (2016 - 1900)));
    if (TimeStruct.tm_year <= (2016 - 1900)) return false;  // the NTP call was not successful
   }
  return true;
}
