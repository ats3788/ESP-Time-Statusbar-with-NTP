#ifndef _TPPROCEDURE_h
#define _NTPPROCEDURE_h

#include <time.h>
#include <Arduino.h>

void SetNTP_SERVER();
bool getNTPtime(int sec,  time_t & GetTime);

#endif