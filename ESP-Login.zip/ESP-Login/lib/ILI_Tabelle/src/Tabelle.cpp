
#include "Tabelle.h"

//********************************************************************************
//  initTable 
//  Adafruit_GFX
//  ScreenRotation - Landscap - Portrait
//  TextColor
//  ListColor
//  BackColor
//********************************************************************************
 void TabelleClass::initTable(Adafruit_GFX* tft, uint8_t ScreenRotation, uint16_t TextColor, uint16_t ListColor, uint16_t BackColor)
{
	_tft = tft;
	_TextColor = TextColor;
	_ListColor = ListColor;
	_BackColor = BackColor;
	_ListPointer = 0;
	_ListOldPointer = 0;
	_Counter = 0;
	
	Serial.printf("tft Init is Address %p ", _tft );
	_tft->setRotation(ScreenRotation);
	if ((ScreenRotation == 1) ^ (ScreenRotation == 3))
	{
		_ScreenWidth = ScreenHeight;
		_ScreenHeight = ScreenWidth;
	}
	else
	{
		_ScreenWidth = ScreenWidth;
		_ScreenHeight = ScreenHeight; 
	}

	_tft->setTextSize(1);
	_tft->fillScreen(_BackColor);
	_tft->setTextColor(_TextColor);

}

 //********************************************************************************
 //  Init_Table_Items
 //  Count - Items in the table
 //  Item  - in the Row
 //********************************************************************************
void TabelleClass::Init_Table_Items(const int Count, tItems Item)
{
	_Count = Count;
	_Items = Item;

	

	switch (_Items) {
	case Items1: Item1 = new String[_Count];   break;
	case Items2: Item1 = new String[_Count];  Item2 = new String[_Count];  break;
	case Items3: Item1 = new String[_Count];  Item2 = new String[_Count];  Item3 = new String[_Count];   break;
	default : break;
	}
}

//********************************************************************************
 //  DrawTableLines
 //  The lines in the Table
 //********************************************************************************
void TabelleClass::DrawTableLines()
{
	_tft->drawFastHLine(3, 10, _ScreenWidth, _TableColor);
	_tft->drawFastHLine(3, 13, _ScreenWidth, _TableColor);

	switch (_Items) {
	case Items1:    break;
	case Items2: _tft->drawFastVLine(_ScreenWidth / 2, 3, _ScreenHeight, _TableColor);  break;
	case Items3: _tft->drawFastVLine(_ScreenWidth / 2, 3, _ScreenHeight, _TableColor); _tft->drawFastVLine(_ScreenWidth / 2 + 45, 3, _ScreenHeight, _TableColor); break;
	default: break;
	}

}

//********************************************************************************
//  initHeadline
//   Text1  - Text Headlines
//   Text2
//   Text3
//   TableColor
//********************************************************************************
void TabelleClass::initHeadline(String Text1, String Text2, String Text3, uint16_t TableColor)
{
	_Text1 = Text1;
	_Text2 = Text2;
	_Text3 = Text3;
	_TableColor = TableColor;

	DrawTableLines();

	_tft->setCursor(13, 2);
	_tft->print(_Text1);
	_tft->setCursor(_ScreenWidth / 2 + 13, 2);
	_tft->print(_Text2);
	_tft->setCursor(_ScreenWidth / 2 + 58, 2);
	_tft->print(_Text3);
}

//********************************************************************************
//  Del_Table_Items
//  delete the Strings in the memory  
//********************************************************************************
void TabelleClass::Del_Table_Items()
{
	switch (_Items) {
	case Items1: delete[] Item1; Item1 = 0;   break;
	case Items2: delete[] Item1; Item1 = 0; delete[] Item2; Item2 = 0;   break;
	case Items3: delete[] Item1; Item1 = 0; delete[] Item2; Item2 = 0; delete[] Item3; Item3 = 0;  break;
	default: break;
	}
}

//********************************************************************************
//  AddItem
//  Value - Text in Table
//  Item  - Col in Table
//********************************************************************************
void TabelleClass::AddItem(String Value, tItems Item)
{
		if (_Counter > _Count -1)
			_Counter = 0;

		Serial.print("cc-->"); Serial.print(_Counter); Serial.print("ss-->"); Serial.print(Value);

		if (_Counter < _Count) {	
		switch (Item) {
		case Items1: Item1[_Counter] = Value; Serial.print("1"); break;
		case Items2: Item2[_Counter] = Value; Serial.print("2"); break;
		case Items3: Item3[_Counter] = Value; Serial.print("3"); break;
		default: break;
		}
	}
		_Counter++;
		Serial.println("<<");
}

//********************************************************************************
//  TextOut
//  X 
//  Y 
//  Text - Output in Table
//********************************************************************************
void TabelleClass::TextOut(uint16_t x, uint16_t y, String Text)
{
	_tft->setCursor(x, y);
	_tft->print(Text);
	Serial.print(Text);
}

//********************************************************************************
//  ShowItem
//  Value - is the Posion in the Table Row
//********************************************************************************
void TabelleClass::ShowItem(int Value)
{
	_tft->setTextColor(_TextColor);
	uint16_t X1 = 5;
	uint16_t X2 = _ScreenWidth / 2 +3;
	uint16_t X3 = _ScreenWidth / 2 + 45 +3;
	uint16_t Y = Value * Mulipikator + StartYPos - 3;

	switch (_Items) {
	case Items1: TextOut(X1, Y, Item1[Value]); Serial.print("Item1"); break;
	case Items2: TextOut(X1, Y, Item1[Value]); TextOut(X2, Y, Item2[Value]); Serial.print("Item2");  break;
	case Items3: TextOut(X1, Y, Item1[Value]); TextOut(X2, Y, Item2[Value]); TextOut(X3, Y, Item3[Value]); 	break;
	default: break;
	}
}

//********************************************************************************
//  ShowItems
//  Output all Items in the Table
//********************************************************************************
void TabelleClass::ShowItems()
{
	for (int i = 0; i < _Count; i++)
	{
		ShowItem(i);
	}
 }

//********************************************************************************
//  MarkItem - in the Table
//  Position 
//********************************************************************************
void TabelleClass::MarkItem(uint16_t Position)
{
	_tft->fillRect(1, Position * Mulipikator  + StartYPos -5, _ScreenWidth -1 , ListHeight +3, _ListColor);
	ShowItem(Position);
}

//********************************************************************************
//  UnMarkItem - in the Table
//  Position 
//********************************************************************************
void TabelleClass::UnMarkItem(uint16_t Position)
{

	_tft->fillRect(1, Position * Mulipikator + StartYPos - 5, _ScreenWidth - 1, ListHeight +3, _BackColor);
	ShowItem(Position);
}

//********************************************************************************
//  ItemUp - in the Table
//********************************************************************************
void TabelleClass::ItemUp()
{
	UnMarkItem(_ListPointer);
	_ListPointer++;
	if (_ListPointer > _Count -1)
		_ListPointer = 0;
	MarkItem(_ListPointer);
	DrawTableLines();
}

//********************************************************************************
//  ItemDown - in the Table
//********************************************************************************
void TabelleClass::ItemDown()
{
	UnMarkItem(_ListPointer);
	_ListPointer--;
	if (_ListPointer < 0)
		_ListPointer = _Count;
	MarkItem(_ListPointer);
	DrawTableLines();
}

 TabelleClass TABELLE;
