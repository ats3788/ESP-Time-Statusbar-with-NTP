// Tabelle.h
// This is a simple example for Arduinos to
// display a simple Table to display Values with One, Two or Three Rows
// (C) 2019 Martin Michael
// I programmed this for the ESP32 Chip to display SSID's
// This Excample is for the UNO-Mega and the ILI9341 MCUFRIEND Display

#ifndef _TABELLE_h
#define _TABELLE_h

#if defined(ARDUINO) && ARDUINO >= 100
	#include "arduino.h"
#else
	#include "WProgram.h"
#endif

#include <WROVER_KIT_LCD.h>
#include <Adafruit_GFX.h> 
#include <stdint.h>

#define Mulipikator  18
#define StartYPos    21
#define ListHeight   15

#define ScreenHeight 320
#define ScreenWidth  240

class TabelleClass
{
private:
	 Adafruit_GFX *_tft = nullptr;
	 String* Item1 = 0;      // Zeiger definieren und sichern
	 String* Item2 = 0;
	 String* Item3 = 0;
	 String _Text1;
	 String _Text2;
	 String _Text3;
	 	 
	 uint16_t _TextColor;
	 uint16_t _ListColor;
	 uint16_t _BackColor;
	 uint16_t _TableColor;
	 
	 bool     _ValueChanged;
	 int      _Count;
	 int      _Counter;
	 
	 uint16_t _ScreenHeight;
	 uint16_t _ScreenWidth;
	 uint8_t  _ListPointer;
	 uint8_t  _ListOldPointer;

	 void TextOut(uint16_t x, uint16_t y, String Text);
	 void MarkItem(uint16_t Position);
	 void UnMarkItem(uint16_t Position);

 public:
	 enum tItems {
		 Items1,
		 Items2,
		 Items3
	 };

	 tItems _Items;

	void initTable(Adafruit_GFX *tft, uint8_t ScreenRotation, uint16_t TextColor, uint16_t ListColor, uint16_t BackColor);
	void Init_Table_Items(const int Count, tItems Item);
	void initHeadline(String Text1, String Text2, String Text3, uint16_t TableColor);
	void DrawTableLines();
	void AddItem(String Value, tItems Item);
	void ShowItems();
	void ShowItem(int Value);
	void ItemUp();
	void ItemDown();
	
	void Del_Table_Items();
};

 extern TabelleClass TABELLE;

#endif

