
#include "StatusBar4Time.h"

  const char  cMonth[12][10] = {"January","February","March","April","May","June","July","August","September","October","November","December"};
  const char  cDay[7][10] =   {"Sunday","Monday","Tuesday","Wednesday","Thursday","Friday","Saturday"};

   int XStart; 
   int XZeit; 
   int XFullMonth;
    


void StatusBar4TimeClass::init(Adafruit_GFX * tft, uint16_t LCDBackgroud, uint16_t TextColor, uint16_t GridColor,  DateType_e DateType)
{
	_tft = tft;
	x_LCDBackgroud = LCDBackgroud;
    x_TextColor = TextColor;
    x_GridColor = GridColor;
	_DateType = DateType;
	XFullMonth = 0;

	switch (_DateType)
	 {
case Plain: XStart = 10; XZeit = 50; break;
case FullMonth : XStart = 10; XZeit = 55; break;
case WithDay : XStart = 70; XZeit = 55; break;
case FullAll : XStart = 90; XZeit = 25;  break;
  	}



	SetStatusBar();
}

bTime StatusBar4TimeClass::CheckTimeChange(time_t OldTime, time_t NewTime)
{
	tm Old;
	tm New;
	bTime b = { 0 };

	localtime_r(&OldTime, &Old);
	localtime_r(&NewTime, &New);

	if (Old.tm_hour != New.tm_hour)
		b.Hour = true;

	if (Old.tm_min != New.tm_min)
		b.Min = true;

	if (Old.tm_sec != New.tm_sec)
		b.Sec = true;

	if (Old.tm_mday != New.tm_mday)
		b.Day = true;

	if (Old.tm_mon != New.tm_mon)
		b.Month = true;

	if (Old.tm_year != New.tm_year)
		b.Year = true;

	return(b);
}

bTime StatusBar4TimeClass::InitTimeChange(bTime b)
{
		b.Hour = true;
		b.Min = true;
		b.Sec = true;
		b.Day = true;
     	b.Month = true;
		b.Year = true;
     	return(b);
}

void StatusBar4TimeClass::SetStatusBar()
{
	_tft->drawFastHLine(0, ScreenY - 25, ScreenX, _GridColor);
	_tft->drawFastHLine(0, ScreenY - 23, ScreenX, _GridColor);
	_tft->fillRect(0, ScreenY - 23, ScreenX, 23, _LCDBackgroud);
}



void  StatusBar4TimeClass::PrintPreDay(uint8_t Day,uint16_t Color)
{
	strcpy(Buffer, cDay[Day]);
 
	_tft->setTextColor(Color);
	_tft->setCursor( 1 , ScreenY - Absatz);
	_tft->print(Buffer);
}


void StatusBar4TimeClass::PrintDay(char S[], uint16_t Color)
{
	_tft->setTextColor(Color);
	_tft->setCursor(XStart + XMult * 0, ScreenY - Absatz);
	_tft->print(S);
}


void StatusBar4TimeClass::PrintMonth(char S[], uint16_t Color)
{
	_tft->setTextColor(Color);
	_tft->setCursor(XStart + XMult * 1, ScreenY - Absatz);
	_tft->print(S);
}

void StatusBar4TimeClass::PrintMonth(uint8_t Monat, uint16_t Color)
{
	 strcpy(Buffer,  cMonth[Monat]);
	_tft->setTextColor(Color);
	_tft->setCursor(XStart  + XMult * 1, ScreenY - Absatz);
	_tft->print(Buffer);
	XFullMonth = strlen(Buffer) * 7; 
}

void StatusBar4TimeClass::PrintYear(char S[], uint16_t Color)
{
	_tft->setTextColor(Color);
	_tft->setCursor(XFullMonth + XStart + XMult * 2, ScreenY - Absatz);
	_tft->print(S);
}


void StatusBar4TimeClass::PrintHour(char S[], uint16_t Color)
{
	_tft->setTextColor(Color);
	_tft->setCursor(XFullMonth + XZeit + XStart + XMult * 3, ScreenY - Absatz);
	_tft->print(S);
}

void StatusBar4TimeClass::PrintMin(char S[], uint16_t Color)
{
	_tft->setTextColor(Color);
	_tft->setCursor(XFullMonth + XZeit + XStart + XMult * 4, ScreenY - Absatz);
	_tft->print(S);
}



void StatusBar4TimeClass::PrintSec(char S[], uint16_t Color)
{
	_tft->setTextColor(Color);
	_tft->setCursor(XFullMonth + XZeit + XStart + XMult * 5, ScreenY - Absatz);
	_tft->print(S);
}





void StatusBar4TimeClass::PrintTime(tm tnew, tm told, bTime b)
{
	char Puffer[4];
   
    if ((_DateType == WithDay) | (_DateType == FullAll))
	{
	if (b.Month) {
	PrintPreDay(told.tm_wday, _LCDBackgroud);
    PrintPreDay(tnew.tm_wday, _TextColor);
	}}
 
   if ((_DateType == FullMonth) |  (_DateType == FullAll))
   {
   if (b.Month) {
		
	    PrintMonth(told.tm_mon, _LCDBackgroud);
		PrintMonth(tnew.tm_mon, _TextColor);
	
	} }
	
	if ((_DateType == Plain) | (_DateType == WithDay))
   {
	if (b.Month) {
		sprintf(Puffer, "%02u ", told.tm_mon);
		PrintMonth(Puffer, _LCDBackgroud);

		sprintf(Puffer, "%02u ", tnew.tm_mon);
		PrintMonth(Puffer, _TextColor);
	}}

	///*************************************


	if (b.Year) {
		sprintf(Puffer, "%04u", told.tm_year);
		PrintYear(Puffer, _LCDBackgroud);

		sprintf(Puffer, "%04u", tnew.tm_year);
		PrintYear(Puffer, _TextColor);
	}

		if (b.Day) {
		sprintf(Puffer, "%02u ", told.tm_mday);
		PrintDay(Puffer, _LCDBackgroud);

		sprintf(Puffer, "%02u ", tnew.tm_mday);
		PrintDay(Puffer, _TextColor);
	}


 	if (b.Hour) {
		sprintf(Puffer, "%02u:", told.tm_hour);
		PrintHour(Puffer, _LCDBackgroud);

		sprintf(Puffer, "%02u:", tnew.tm_hour);
		PrintHour(Puffer, _TextColor);
	}
	if (b.Min) {
		sprintf(Puffer, "%02u:", told.tm_min);
		PrintMin(Puffer, _LCDBackgroud);

		sprintf(Puffer, "%02u:", tnew.tm_min);
		PrintMin(Puffer, _TextColor);

	}
	if (b.Sec) {
		sprintf(Puffer, "%02u", told.tm_sec);
		PrintSec(Puffer, _LCDBackgroud);

		sprintf(Puffer, "%02u", tnew.tm_sec);
		PrintSec(Puffer, _TextColor);
	} 
}


void StatusBar4TimeClass::SetTime(time_t NewTime, time_t OldTime)
{
	tm ZNeu, ZAlt;
	bTime b;
	
	localtime_r(&NewTime, &ZNeu);
	ZNeu.tm_year += 1900;
	ZNeu.tm_mon -= 1;
	localtime_r(&OldTime, &ZAlt);
	ZAlt.tm_year += 1900;
	ZAlt.tm_mon -= 1;
	b = CheckTimeChange(NewTime, OldTime);

    if (bFirstStep)
	{
    b = InitTimeChange(b);
    bFirstStep = false; 
	}	
	
	PrintTime(ZNeu, ZAlt, b);
}
