

#ifndef _StatusBar_h
#define _StatusBar_h


#include "arduino.h"

#include <Adafruit_GFX.h> 
#include "comici8pt.c"
#include "ILI9341_Colors.h"
#include "time.h"

#define ScreenX 320
#define ScreenY 240
#define XMult   23
//#define XStart 10

#define Absatz 6



#define _LCDBackgroud  ILI9341_AQUA
#define _TextColor  ILI9341_RED
#define _GridColor  ILI9341_RED


enum DateType_e  {
Plain,
FullMonth,
WithDay,
FullAll
} ;

struct bTime
{
    bool Hour;
    bool Min;
    bool Sec;

    bool Day;
    bool Month;
    bool Year;
};

class StatusBar4TimeClass
{
private:
   
   char Buffer[12];

  DateType_e _DateType;
 bool bFirstStep = true;

   uint16_t  x_LCDBackgroud;
   uint16_t  x_TextColor;
   uint16_t  x_GridColor;
   time_t NewTime = 0x0;
   time_t OldTime = 0xffffffff;

	 Adafruit_GFX * _tft;
     bTime CheckTimeChange(time_t OldTime, time_t NewTime);
     bTime InitTimeChange(bTime b);
	 void SetStatusBar();
     void PrintTime(tm tnew, tm told, bTime b);
     void PrintPreDay(uint8_t Day,uint16_t Color);
     void PrintDay(char S[], uint16_t Color);
     void PrintMonth(char S[], uint16_t Color);
     void PrintMonth(uint8_t Monat, uint16_t Color);
     void PrintYear(char S[], uint16_t Color);
     void PrintHour(char S[], uint16_t Color);
     void PrintMin(char S[], uint16_t Color);
     void PrintSec(char S[], uint16_t Color);
     
 
 public:
  
	void init(Adafruit_GFX * tft, uint16_t LCDBackgroud, uint16_t TextColor, uint16_t GridColor, DateType_e DateType);
    void SetTime(time_t NewTime, time_t OldTime);
  
};

#endif

