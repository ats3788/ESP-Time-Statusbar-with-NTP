  

#include "Keyboard.h"

//********************************************************************************
//  init
//  Adafruit_GFX
//  TextOutColor
//  BackColor
//********************************************************************************

void KeyboardClass::init(Adafruit_GFX* tft, uint16_t TextOutColor, uint16_t BackColor)
{
	_tft = tft;
	_TextOutColor = TextOutColor;
	_BackColor = BackColor;
	
	_tft->setRotation(1); // Landscape
	_ScreenWidth = ScreenHeight;
	_ScreenHeight = ScreenWidth;
	
	_CharCounter = 0;
	_CharCounterOld = 0;
	_KeyStatus = Capital;
	_tft->setTextSize(1);
	_tft->fillScreen(_BackColor);
	
	// Just Default Colors ---
	CurrentColor.KeyColor = ILI9341_LEMONCHIFFON;
	CurrentColor.KeyShadow = ILI9341_CORAL;
	CurrentColor.KeyFrameColor = ILI9341_DARKCYAN;
	CurrentColor.KeyTextColor = ILI9341_DARKBLUE;

	PressedColor.KeyColor = ILI9341_YELLOWGREEN;
	PressedColor.KeyShadow = ILI9341_LIGHTPINK;
	PressedColor.KeyFrameColor = ILI9341_WHITE;
	PressedColor.KeyTextColor = ILI9341_DARKGRAY;

	}

//********************************************************************************
//  SetKeyColor
//  KeyColor
//  KeyShadow
//  KeyFrameColor
//  KeyTextColor
//********************************************************************************
void KeyboardClass::SetKeyColor(uint16_t KeyColor, uint16_t KeyShadow, uint16_t KeyFrameColor, uint16_t KeyTextColor)
{
	CurrentColor.KeyColor = KeyColor;
	CurrentColor.KeyFrameColor = KeyShadow;
	CurrentColor.KeyShadow = KeyFrameColor;
	CurrentColor.KeyTextColor = KeyTextColor;
}

//********************************************************************************
//  SetPressedKeyColor
//  KeyColor
//  KeyShadow
//  KeyFrameColor
//  KeyTextColor
//********************************************************************************
void KeyboardClass::SetPressedKeyColor(uint16_t KeyColor, uint16_t KeyShadow, uint16_t KeyFrameColor, uint16_t KeyTextColor)
{
	PressedColor.KeyColor = KeyColor;
	PressedColor.KeyFrameColor = KeyShadow;
	PressedColor.KeyShadow = KeyFrameColor;
	PressedColor.KeyTextColor = KeyTextColor;
}


//********************************************************************************
//  GetFromPROGMEM
//  Value
//
// tButton the Values where x - y how big h - w and the Current Colors
//********************************************************************************
tButton KeyboardClass::GetFromPROGMEM(uint8_t Value)
{
	tButton Result;
	Result.x = KeyButton[Value].x; // pgm_read_word(&(KeyButton[Value].x));
	Result.y = KeyButton[Value].y;//	pgm_read_word(&(KeyButton[Value].y));
	Result.h = KeyButton[Value].h; // pgm_read_word(&(KeyButton[Value].h));
	Result.w = KeyButton[Value].w;  //pgm_read_word(&(KeyButton[Value].w));
/*
	Result.KeyColor = KeyButton[Value].KeyColor; // pgm_read_word(&(KeyButton[Value].KeyCol));
	Result.KeyShadow = KeyButton[Value].KeyShadow; // pgm_read_word(&(KeyButton[Value].Shadow));
	Result.KeyFrameColor = KeyButton[Value].KeyFrameColor; // pgm_read_word(&(KeyButton[Value].SColor));
	Result.KeyTextColor = KeyButton[Value].KeyTextColor; // pgm_read_word(&(KeyButton[Value].KeyTextColor));
	*/
	Result.KeyColor = CurrentColor.KeyColor;
	Result.KeyShadow = CurrentColor.KeyShadow;
	Result.KeyFrameColor = CurrentColor.KeyFrameColor;
	Result.KeyTextColor = CurrentColor.KeyTextColor;
	return (Result);
}

//********************************************************************************
//  drawButton
//  Value
//********************************************************************************
void KeyboardClass::drawButton(const tButton Value)
{
	uint16_t x = Value.x;
	uint16_t y = Value.y;
	uint16_t h = Value.h;
	uint16_t w = Value.w;
	uint16_t ShadowColor = Value.KeyShadow;
	uint16_t FrameColor = Value.KeyFrameColor;
	uint16_t KeyColor = Value.KeyColor;
	

	_tft->fillRoundRect(x - 3, y + 3, w, h, 3, ShadowColor); //Button Shading
	_tft->fillRoundRect(x, y, w, h, 3, FrameColor);// outter button color
	_tft->fillRoundRect(x + 1, y + 1, w - 1 * 2, h - 1 * 2, 3, KeyColor); //inner button color
}


//********************************************************************************
//  drawButton
//  x
//  y
//  Value
//  Color
//********************************************************************************
void KeyboardClass::drawButtonText(uint16_t x, uint16_t y, char Value, uint16_t Color)
{
	_tft->setTextColor(Color);
	_tft->setCursor(x + 7, y + 11);
	_tft->print(Value);
}

//********************************************************************************
//  Show
//  Key
//********************************************************************************
void KeyboardClass::Show(tKeyStatus  Key)
{

	uint16_t x;
	uint16_t y;
	char ch;

	for (int i = 0; i < 39; i++) {
		 tButton Button = GetFromPROGMEM(i);
		
		drawButton(Button);

		x = i % 10;
		y = i / 10;
		if (Key == Capital)
			ch = Mobile_KBCapital[y][x];//pgm_read_byte(&(Mobile_KBCapital[y][x]));
		if (Key == Small)
			ch = Mobile_KBSmall[y][x]; // pgm_read_byte(&(Mobile_KBSmall[y][x]));

		_tft->setTextSize(2);
		
		drawButtonText(Button.x, Button.y,ch, Button.KeyTextColor);
	//	Serial.println(ch);
	}
}

//********************************************************************************
// SetStepColor
// Value
// Key
// Color
//********************************************************************************
void KeyboardClass::SetStepColor(int8_t Value, tKeyStatus  Key, tButton Color)
{
	char ch = GetKeyChar(Value, Key);
	SetButtonColor(Value, ch, Color);
}

//********************************************************************************
// GetKeyChar
// Value
// Key
//
// char The right char from the Key Array
//********************************************************************************
char  KeyboardClass::GetKeyChar(uint8_t Value, tKeyStatus Key)
{
	uint16_t x;
	uint16_t y;
	char Result;
	x = Value % 10;
	y = Value / 10;
	if (Key == Capital)
		Result = Mobile_KBCapital[y][x]; // pgm_read_byte(&(Mobile_KBCapital[y][x]));
	if (Key == Small)
		Result = Mobile_KBSmall[y][x]; // pgm_read_byte(&(Mobile_KBSmall[y][x]));
	return (Result);
}

//********************************************************************************
// SetButtonColor
// Value
// Text
// Color
//********************************************************************************
void KeyboardClass::SetButtonColor(uint8_t Value, char Text, tButton Color)
{
	tButton Button = GetFromPROGMEM(Value);

	Button.KeyColor = Color.KeyColor; 
	Button.KeyShadow = Color.KeyShadow; 
	Button.KeyFrameColor = Color.KeyFrameColor; 
	Button.KeyTextColor = Color.KeyTextColor;


	drawButton(Button);
	drawButtonText(Button.x, Button.y, Text, Button.KeyTextColor);
}

//********************************************************************************
// Check4Key
// Value
// Key
//********************************************************************************
void KeyboardClass::Check4Key(uint8_t Value, tKeyStatus   Key)
{
	// Serial.print("Value is ");
	// Serial.println(Value);
	if (Value == 38)
	{
		if (Key == Small)
			Key = Capital;
		else
			Key = Small;
	}
	
	_KeyStatus = Key;
	char ch = GetKeyChar(Value, Key);
	if (Value == 38) 
		Show(Key);
	else
		SetLCDText(ch);
}

//********************************************************************************
// SetLCDText
// Value
//********************************************************************************
void KeyboardClass::SetLCDText(const char Value)
{
	if (Value == 60)
	{
		_tft->setCursor(10, 10);
		_tft->setTextColor(_BackColor);
		_tft->print(_TextBuffer);
		_TextBuffer.remove(_TextBuffer.length() - 1);
		Serial.println(_TextBuffer);
	}
	else
	{
		if (_TextBuffer.length() < 22) {
			_TextBuffer = _TextBuffer + Value;
		}
	}
	_tft->setTextColor(_TextOutColor);
	_tft->setCursor(10, 10);
	_tft->print(_TextBuffer);
}

//********************************************************************************
// Up
//********************************************************************************
void KeyboardClass::Up()
{
	SetStepColor(_CharCounterOld, _KeyStatus, CurrentColor);
	_CharCounter++;
	if (_CharCounter > 38)
		_CharCounter = 0;

		SetStepColor(_CharCounter, _KeyStatus, PressedColor);
		_CharCounterOld = _CharCounter;
}

//********************************************************************************
// Down
//********************************************************************************
void KeyboardClass::Down()
{
	SetStepColor(_CharCounterOld, _KeyStatus, CurrentColor);
	_CharCounter--;
	if (_CharCounter < 0)
		_CharCounter = 38;
	SetStepColor(_CharCounter, _KeyStatus, PressedColor);
	_CharCounterOld = _CharCounter;
}

//********************************************************************************
// Enter
//********************************************************************************
void KeyboardClass::Enter()
{
	Check4Key(_CharCounter, _KeyStatus);
}

//********************************************************************************
// GetKeyResult
//
// String The final Text from the Keyboard
//********************************************************************************
String KeyboardClass::GetKeyResult()
{
	return(_TextBuffer);
}


KeyboardClass Keyboard;

