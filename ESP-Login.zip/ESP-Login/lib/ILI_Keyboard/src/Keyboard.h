// Keyboard.h

#ifndef _KEYBOARD_h
#define _KEYBOARD_h

#if defined(ARDUINO) && ARDUINO >= 100
	#include "arduino.h"
    #include "ILI9341_Colors.h"
	#include <MCUFRIEND_kbv.h>
	#include <Adafruit_GFX.h> 
	#include <stdint.h>
#else
	#include "WProgram.h"
#endif
// For Portrait
#define ScreenHeight 320
#define ScreenWidth  240

enum tKeyStatus
	{
		Capital,
		Small
	};

enum tKeyState
{
	New,
	Old
};

struct tKeyButton {
	int8_t ButtonMerker = -1;
	char Text;
};


struct tButton {
	uint16_t x;
	uint16_t y;
	uint16_t h;
	uint16_t w;
	uint16_t KeyColor;
	uint16_t KeyShadow;
	uint16_t KeyFrameColor;
	uint16_t KeyTextColor;
};



class KeyboardClass
{
 
tKeyStatus eKeyStatus;
tButton _Button;
bool bKeyChar = false;
String _TextBuffer;
char Buffer[30];

uint16_t ILI9341_Key = ILI9341_DARKBLUE;
uint16_t ILI9341_Shadow = ILI9341_CORAL;
uint16_t ILI9341_Frame = ILI9341_WHITESMOKE;
uint16_t ILI9341_Text = ILI9341_GRAY;


#define _x1_ 10
#define _x2_ 20
#define _x3_ 40
#define _x4_ 50

#define _X_ 30

#define _y1_ 40
#define _Y_ 40
	 // 1-4              x     y        h   w    Color Button      
#define ButtonSpace {60, _y1_ * 5, 35, 195, ILI9341_Key, ILI9341_Shadow, ILI9341_Frame,ILI9341_GRAY}
#define ButtonBack {270, _y1_ * 5, 35, 40, ILI9341_Key, ILI9341_Shadow, ILI9341_Frame,ILI9341_GRAY}
//#define ButtonReturn {270, _y1_ * 4, 35, 40, ILI9341_LAVENDER, ILI9341_Shadow, ILI9341_Frame,ILI9341_GRAY}
#define ButtonShift {15,  _y1_ * 5, 35, 40, ILI9341_Key, ILI9341_Shadow, ILI9341_Frame,ILI9341_GRAY}
// 5- 14
#define Button1 { _x1_           , _y1_, 35, 25, ILI9341_Key, ILI9341_Shadow,ILI9341_Frame,ILI9341_GRAY}
#define Button2 { _x1_ + _X_ * 1 , _y1_, 35, 25, ILI9341_Key, ILI9341_Shadow,ILI9341_Frame,ILI9341_GRAY}
#define Button3 { _x1_ + _X_ * 2 , _y1_, 35, 25, ILI9341_Key, ILI9341_Shadow,ILI9341_Frame,ILI9341_GRAY}
#define Button4 { _x1_ + _X_ * 3 , _y1_, 35, 25, ILI9341_Key, ILI9341_Shadow,ILI9341_Frame,ILI9341_GRAY}
#define Button5 { _x1_ + _X_ * 4 , _y1_, 35, 25, ILI9341_Key, ILI9341_Shadow,ILI9341_Frame,ILI9341_GRAY}
#define Button6 { _x1_ + _X_ * 5 , _y1_, 35, 25, ILI9341_Key, ILI9341_Shadow,ILI9341_Frame,ILI9341_GRAY}
#define Button7 { _x1_ + _X_ * 6 , _y1_, 35, 25, ILI9341_Key, ILI9341_Shadow,ILI9341_Frame,ILI9341_GRAY}
#define Button8 { _x1_ + _X_ * 7 , _y1_, 35, 25, ILI9341_Key, ILI9341_Shadow,ILI9341_Frame,ILI9341_GRAY}
#define Button9 { _x1_ + _X_ * 8 , _y1_, 35, 25, ILI9341_Key, ILI9341_Shadow,ILI9341_Frame,ILI9341_GRAY}
#define Button0 { _x1_ + _X_ * 9 , _y1_, 35, 25, ILI9341_Key, ILI9341_Shadow,ILI9341_Frame,ILI9341_GRAY}
//15 - 40
#define ButtonQ { _x2_          , _Y_ * 2 , 35, 25, ILI9341_Key, ILI9341_Shadow,ILI9341_Frame,ILI9341_GRAY}
#define ButtonW { _x2_ + _X_ * 1, _Y_ * 2 , 35, 25, ILI9341_Key, ILI9341_Shadow,ILI9341_Frame,ILI9341_GRAY}
#define ButtonE { _x2_ + _X_ * 2, _Y_ * 2 , 35, 25, ILI9341_Key, ILI9341_Shadow,ILI9341_Frame,ILI9341_GRAY}
#define ButtonR { _x2_ + _X_ * 3, _Y_ * 2 , 35, 25, ILI9341_Key, ILI9341_Shadow,ILI9341_Frame,ILI9341_GRAY}
#define ButtonT { _x2_ + _X_ * 4, _Y_ * 2 , 35, 25, ILI9341_Key, ILI9341_Shadow,ILI9341_Frame,ILI9341_GRAY}
#define ButtonZ { _x2_ + _X_ * 5, _Y_ * 2 , 35, 25, ILI9341_Key, ILI9341_Shadow,ILI9341_Frame,ILI9341_GRAY}
#define ButtonU { _x2_ + _X_ * 6, _Y_ * 2 , 35, 25, ILI9341_Key, ILI9341_Shadow,ILI9341_Frame,ILI9341_GRAY}
#define ButtonI { _x2_ + _X_ * 7, _Y_ * 2 , 35, 25, ILI9341_Key, ILI9341_Shadow,ILI9341_Frame,ILI9341_GRAY}
#define ButtonO { _x2_ + _X_ * 8, _Y_ * 2 , 35, 25, ILI9341_Key, ILI9341_Shadow,ILI9341_Frame,ILI9341_GRAY}
#define ButtonP { _x2_ + _X_ * 9, _Y_ * 2 , 35, 25, ILI9341_Key, ILI9341_Shadow,ILI9341_Frame,ILI9341_GRAY}
#define ButtonA { _x3_          , _Y_ * 3 , 35, 25, ILI9341_Key, ILI9341_Shadow,ILI9341_Frame,ILI9341_GRAY}
#define ButtonS { _x3_ + _X_ * 1, _Y_ * 3 , 35, 25, ILI9341_Key, ILI9341_Shadow,ILI9341_Frame,ILI9341_GRAY}
#define ButtonD { _x3_ + _X_ * 2, _Y_ * 3 , 35, 25, ILI9341_Key, ILI9341_Shadow,ILI9341_Frame,ILI9341_GRAY}
#define ButtonF { _x3_ + _X_ * 3, _Y_ * 3 , 35, 25, ILI9341_Key, ILI9341_Shadow,ILI9341_Frame,ILI9341_GRAY}
#define ButtonG { _x3_ + _X_ * 4, _Y_ * 3 , 35, 25, ILI9341_Key, ILI9341_Shadow,ILI9341_Frame,ILI9341_GRAY}
#define ButtonH { _x3_ + _X_ * 5, _Y_ * 3, 35, 25, ILI9341_Key, ILI9341_Shadow,ILI9341_Frame,ILI9341_GRAY}
#define ButtonJ { _x3_ + _X_ * 6, _Y_ * 3, 35, 25, ILI9341_Key, ILI9341_Shadow,ILI9341_Frame,ILI9341_GRAY}
#define ButtonK { _x3_ + _X_ * 7, _Y_ * 3, 35, 25, ILI9341_Key, ILI9341_Shadow,ILI9341_Frame,ILI9341_GRAY}
#define ButtonL { _x3_ + _X_ * 8, _Y_ * 3, 35, 25, ILI9341_Key, ILI9341_Shadow,ILI9341_Frame,ILI9341_GRAY}
#define ButtonY { _x4_          , _Y_ * 4, 35, 25, ILI9341_Key, ILI9341_Shadow,ILI9341_Frame,ILI9341_GRAY}
#define ButtonX { _x4_ + _X_ * 1, _Y_ * 4, 35, 25, ILI9341_Key, ILI9341_Shadow,ILI9341_Frame,ILI9341_GRAY}
#define ButtonC { _x4_ + _X_ * 2, _Y_ * 4, 35, 25, ILI9341_Key, ILI9341_Shadow,ILI9341_Frame,ILI9341_GRAY}
#define ButtonV { _x4_ + _X_ * 3, _Y_ * 4, 35, 25, ILI9341_Key, ILI9341_Shadow,ILI9341_Frame,ILI9341_GRAY}
#define ButtonB { _x4_ + _X_ * 4, _Y_ * 4, 35, 25, ILI9341_Key, ILI9341_Shadow,ILI9341_Frame,ILI9341_GRAY}
#define ButtonN { _x4_ + _X_ * 5, _Y_ * 4, 35, 25, ILI9341_Key, ILI9341_Shadow,ILI9341_Frame,ILI9341_GRAY}
#define ButtonM { _x4_ + _X_ * 6, _Y_ * 4, 35, 25, ILI9341_Key, ILI9341_Shadow,ILI9341_Frame,ILI9341_GRAY}

	 const char Mobile_KBCapital[4][10]  = {
	   {'1' , '2' , '3' , '4' , '5' , '6' , '7' , '8' , '9' , '0'},
	   {'Q' , 'W' , 'E' , 'R' , 'T' , 'Z' , 'U' , 'I' , 'O' , 'P'},
	   {'A' , 'S' , 'D' , 'F' , 'G' , 'H' , 'J' , 'K' , 'L' , 'Y'},
	   {'X' , 'C' , 'V' , 'B' , 'N' , 'M' , ' ' , '<' , '^' , ' '}
	 };

	 const char Mobile_KBSmall[4][10]  = {
	   {'1' , '2' , '3' , '4' , '5' , '6' , '7' , '8' , '9' , '0'},
	   {'q' , 'w' , 'e' , 'r' , 't' , 'z' , 'u' , 'i' , 'o' , 'p'},
	   {'a' , 's' , 'd' , 'f' , 'g' , 'h' , 'j' , 'k' , 'l' , 'y'},
	   {'x' , 'c' , 'v' , 'b' , 'n' , 'm' , ' ' , '<'  , '^', ' '}
	 };

	 const struct tButton KeyButton[40] = { Button1, Button2, Button3, Button4, Button5, Button6, Button7, Button8, Button9, Button0, \
	 ButtonQ, ButtonW, ButtonE, ButtonR, ButtonT, ButtonZ, ButtonU, ButtonI, ButtonO, ButtonP, ButtonA, ButtonS, ButtonD, ButtonF, ButtonG, ButtonH, ButtonJ, ButtonK, ButtonL, \
	 ButtonY, ButtonX, ButtonC, ButtonV, ButtonB, ButtonN, ButtonM, ButtonSpace, ButtonBack, ButtonShift };

private:
	Adafruit_GFX* _tft = nullptr;
	uint16_t _BackColor;
	uint16_t _TextOutColor;

	uint16_t _ScreenWidth;
	uint16_t _ScreenHeight;
	int8_t   _CharCounter;
	int8_t   _CharCounterOld;

	tKeyStatus _KeyStatus;
	tButton CurrentColor;
	tButton PressedColor;
	

 tButton GetFromPROGMEM(uint8_t Value);
 void drawButton(const tButton Value);
 void drawButtonText(uint16_t x, uint16_t y, char Value, uint16_t Color);
  
 void SetStepColor(int8_t Value, tKeyStatus  Key, tButton Color);
 char GetKeyChar(uint8_t Value, tKeyStatus Key);
 void SetButtonColor(uint8_t Value, char Text, tButton Color);
 void Check4Key(uint8_t Value, tKeyStatus Key);
 void SetLCDText(const char Value);

 public:
	
	void init(Adafruit_GFX* tft, uint16_t TextOutColor,  uint16_t BackColor);
	void SetKeyColor(uint16_t KeyColor, uint16_t KeyShadow, uint16_t KeyFrameColor, uint16_t KeyTextColor);
	void SetPressedKeyColor(uint16_t KeyColor, uint16_t KeyShadow, uint16_t KeyFrameColor, uint16_t KeyTextColor);
	void Show(tKeyStatus  Key);
	void Up();
	void Down();
	void Enter();
	String GetKeyResult();
};

extern KeyboardClass Keyboard;

#endif

