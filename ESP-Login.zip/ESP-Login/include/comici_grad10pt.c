#ifndef comici_grad10pt
#define comici_grad10pt

#ifdef __AVR__
 #include <avr/io.h>
 #include <avr/pgmspace.h>
#elif defined(ESP8266)
 #include <pgmspace.h>
#else
 #define PROGMEM
#endif

#include "gfxfont.h"
#include <stdint.h>

static const uint8_t  comici_grad10ptBitmaps[] PROGMEM = {
  0x38, 0xda, 0x14, 0x28, 0x5b, 0x9c, 0x00 };



static const GFXglyph comici_grad10ptGlyphs[] PROGMEM = {
  {     0,   7,   7,   8,    3,  -16 } }; // 0xb0




const GFXfont  _comici_grad10pt_  PROGMEM = {
  (uint8_t  *)comici_grad10ptBitmaps,
  
(GFXglyph *)comici_grad10ptGlyphs,

  0xb0, 0xb0, 28 

};

#endif
