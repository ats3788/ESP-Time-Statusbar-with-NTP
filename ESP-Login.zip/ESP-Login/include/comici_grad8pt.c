#ifndef comici_grad8pt
#define comici_grad8pt

#ifdef __AVR__
 #include <avr/io.h>
 #include <avr/pgmspace.h>
#elif defined(ESP8266)
 #include <pgmspace.h>
#else
 #define PROGMEM
#endif

#include "gfxfont.h"
#include <stdint.h>

static const uint8_t  comici_grad8ptBitmaps[] PROGMEM = {
  0x39, 0x28, 0xe2, 0xd9, 0xc0 };



static const GFXglyph comici_grad8ptGlyphs[] PROGMEM = {
  {     0,   6,   6,   7,    2,  -13 } }; // 0xb0




const GFXfont  _comici_grad8pt_  PROGMEM = {
  (uint8_t  *)comici_grad8ptBitmaps,
  
(GFXglyph *)comici_grad8ptGlyphs,

  0xb0, 0xb0, 22 

};

#endif
